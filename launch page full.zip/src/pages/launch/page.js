import React from 'react'

const page = () => {
  return (
    <div>
      <p>
        hi
      </p>
    </div>
  )
}

export default page
